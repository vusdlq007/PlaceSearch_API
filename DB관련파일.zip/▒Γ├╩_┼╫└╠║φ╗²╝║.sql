CREATE DATABASE place_search;

create table T_PLACE_SEARCH_INFO
(
    SEQ        bigint auto_increment
        primary key,
    KEYWORD    varchar(200) not null comment '검색 키워드',
    VIEWS      bigint       null comment '누적 검색 횟수',
    UPDATED_AT datetime     null comment '최근 업데이트 시간',
    CREATED_AT datetime     null comment '최초 검색 시간'
)
    comment '장소 검색 검색 정보 관리';

create table T_SEARCH_LOG
(
    CREATED_AT datetime     null comment ' 로그최초저장시간.',
    SEQ        bigint auto_increment
        primary key,
    MAC_ADD    varchar(100) null,
    OS         varchar(100) null,
    KEYWORD    varchar(100) not null
)
    comment '장소 검색 로그 테이블';

commit;
